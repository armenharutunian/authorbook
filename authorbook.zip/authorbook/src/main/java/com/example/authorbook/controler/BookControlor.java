package com.example.authorbook.controler;

import com.example.authorbook.Repository.AuthorRepository;
import com.example.authorbook.Repository.BookRepository;
import com.example.authorbook.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BookControlor {

    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private AuthorRepository authorRepository;
    @GetMapping("/book/add")
    public String addAuthorView(ModelMap map){
        map.addAttribute("authors", authorRepository.findAll());
        return "addBook";
    }
    @PostMapping("/book/add")
    public String addAuthor(@ModelAttribute Book book){
        bookRepository.save(book);
        return "redirect:/";
    }
}
