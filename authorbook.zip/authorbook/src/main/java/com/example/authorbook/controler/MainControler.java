package com.example.authorbook.controler;

import com.example.authorbook.Repository.BookRepository;
import com.example.authorbook.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MainControler {

    @Autowired
    private BookRepository bookRepository;

   @GetMapping("/")
   public String main(ModelMap map){
       List<Book> all = bookRepository.findAll();
       map.addAttribute("Books", all);
       return "index";
   }
}
