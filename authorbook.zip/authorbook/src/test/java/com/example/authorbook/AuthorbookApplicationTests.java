package com.example.authorbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorbookApplicationTests {

    @Test
    void contextLoads() {
    }

}
